$(document).ready(function () {
    $('#dtHorizontal').DataTable({
        "scrollX": true
    });
    $('.dataTables_length').addClass('bs-select');
});